
import sun.print.PeekGraphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */
public class Main {

    public static void main(String[] args) throws Exception {
        System.out.println("=====Management Person programer=====");
        System.out.println("Input Information of Person");
        ManagementPerson m = new ManagementPerson();
        int n = CheckInput.inputInt();
        Person[] persons = new Person[n];
        for (int i = 0; i < persons.length; i++) {
            persons[i] = ManagementPerson.inputPersonInfo();

        }

    }
}
