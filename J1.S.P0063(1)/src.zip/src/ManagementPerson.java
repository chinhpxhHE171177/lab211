
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */
public class ManagementPerson extends Person {

    static Person inputPersonInfo() throws Exception {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Input Information of Person");
        System.out.print("Please input name: ");
        String name = CheckInput.inputString();

        System.out.print("Please input address: ");
        String address = CheckInput.inputString();

        System.out.print("Please input salary: ");
        double salary = CheckInput.inputSalary();

        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ManagementPerson(String name, String address, double salary) {
        super(name, address, salary);
    }

    public ManagementPerson() {
    }

    private static void displayPersonInfo(Person person) {
        System.out.println("Information of Person you have entered: ");
        System.out.println("Name: " + person.getName());
        System.out.println("Address: " + person.getAddress());
        System.out.println("Salary: " + person.getSalary());
        System.out.println();
    }

    private static Person[] sortBySalary(Person[] persons) {
        if (persons == null || persons.length == 0) {
            System.out.println("Can't sort Person array");
        }

        boolean sorted = false;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < persons.length - 1; i++) { // vong lap duyet tu dau den cuoi mang
                for (int j = i; j < persons.length; j++) {
                    if (persons[i].getSalary() > persons[j].getSalary()) {
                        Person temp = persons[i];
                        persons[i] = persons[j];
                        persons[j] = temp;
                        // sorted = false;
                    }
                }
            }
        }
        return persons;// vong lap kethuc va mnag person đc sx dc tra ve
    }

}
